
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Listing from './Listing';
import Create from './Create';
import Detail from './Detail';
import Edit from './Edit';
import PageNotFound from "./PageNotFound";
import 'font-awesome/css/font-awesome.min.css';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Listing />}></Route>
          <Route path='/employee/create' element={<Create />}></Route>

          <Route path='/employee/detail/:empid' element={<Detail />}></Route>
          <Route path='/employee/edit/:empid' element={<Edit />}></Route>
          <Route path='*' element={<PageNotFound />}> </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );

}

export default App;
