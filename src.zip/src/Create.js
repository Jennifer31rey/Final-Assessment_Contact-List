import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./styles/css/myStyle.css";
import 'font-awesome/css/font-awesome.min.css';

const Create = () => {

    const[id,idchange]=useState("");
    const[name,namechange]=useState("");
    const[email,emailchange]=useState("");
    const[phone,phonechange]=useState("");
    const[active,activechange]=useState(true);
    const[validation,valchange]=useState(false);

   


    const navigate=useNavigate();

    const handlesubmit=(e)=>{
      e.preventDefault();
      const empdata={name,email,phone,active};
      

      fetch("http://localhost:4000/employee",{
        method:"POST",
        headers:{"content-type":"application/json"},
        body:JSON.stringify(empdata)
      }).then((res)=>{
        alert('Saved successfully.')
        navigate('/');
      }).catch((err)=>{
        console.log(err.message)
      })

    }


    return (
        <div className="Image" >

            <div className="row">
                <div className="offset-lg-3 col-lg-6">
                    <form className="container" onSubmit={handlesubmit}>

                        <div className="card" style={{"textAlign":"left"}}>
                            <div className="card-title">
                                <p className="p">Employee Create</p>
                            </div>
                            <div className="card-body">

                                <div className="row">

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label className="text">ID</label>
                                            <i class="fa far fa-id-card"></i>
                                            <input value={id}  onChange={e=>idchange(e.target.value)}disabled="disabled" className="form-control"></input>
                                            <i class='bx bx-user' ></i>
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label className="text">Name</label>
                                            <i class="fa fas fa-signature"></i>
                                            <input required value={name} placeholder="Enter your Name" onMouseDown={e=>valchange(true)} onChange={e=>namechange(e.target.value)} className="form-control"></input>
                                        {name.length===0 && validation && <span className="text-danger">Enter the name</span>}
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label className="text">Email</label>
                                            <i class="fa far fa-envelope"></i>
                                            <input value={email}  placeholder="Enter your Email" type="email" onChange={(e)=> emailchange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label className="text">Phone</label>
                                            <i class="fa fal fa-phone"></i>
                                            <input value={phone} placeholder="Enter your contact number" name="phone" onChange={(e)=>phonechange(e.target.value)} className="form-control" type="tel" pattern="[0-9]{11}"></input>
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-check">
                                        <input checked={active} onChange={e=>activechange(e.target.checked)} type="checkbox" className="form-check-input"></input>
                                            <label  className="form-check-label">Is Active</label>
                                            
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                           <button className="btn-submit" type="submit">Save</button>
                                           <Link to="/" className=".btn-back">Back</Link>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </form>

                </div>
            </div>
        </div>
    );
}

export default Create;