import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import "./styles/css/EmpDetails.css";


const EmpDetail = () => {
    const { empid } = useParams();

    const [empdata, empdatachange] = useState({});

    useEffect(() => {
        fetch("http://localhost:4000/employee/" + empid).then((res) => {
            return res.json();
        }).then((resp) => {
            empdatachange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, [empid]);
    return (
        <div>
            {/* <div className="row">
                <div className="offset-lg-3 col-lg-6"> */}

               <div className="container">
                
            <div className="card row" style={{ "textAlign": "left" }}>
                <div className="card-title">
                    <p className="p">Employee Contact Details</p>
                </div>
                <div className="card-body"></div>

                {empdata &&
                    <div>
                        <h2 className="bg">The Employee name is : <b>{empdata.name}</b>  ({empdata.id})</h2>
                        <p className="i">Contact Details</p>
                        <p className="info">Email is : {empdata.email}</p>
                        <p className="info">Phone is : {empdata.phone}</p>
                        <Link className="btn-goback" to="/">Back to Listing</Link>
                    </div>
                }
            </div>
            </div>
            {/* </div>
            </div> */}
        </div >
    );
}

export default EmpDetail;