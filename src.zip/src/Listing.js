import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./styles/css/empListing.css";

const Listing = () => {
    const [empdata, empdatachange] = useState(null);
    const navigate = useNavigate();

    const LoadDetail = (id) => {
        navigate("/employee/detail/" + id);
    }
    const LoadEdit = (id) => {
        navigate("/employee/edit/" + id);
    }
    const Removefunction = (id) => {
        if (window.confirm('Do you want to remove?')) {
            fetch("http://localhost:4000/employee/" + id, {
                method: "DELETE"
            }).then((res) => {
                alert('Removed successfully.')
                window.location.reload();
            }).catch((err) => {
                console.log(err.message)
            })
        }
    }

    useEffect(() => {
        fetch("http://localhost:4000/employee").then((res) => {
            return res.json();
        }).then((resp) => {
            empdatachange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, [])
    return (
        <div className="container">
            <div className="card">
                <div className="card-title">
                    <p className="title">Employee Listing</p>
                        <p className="bh">Welcome! Please see below the added contacts.</p>
                </div>
                <div className="card-body">
                    <table className="table table-bordered">
                        <thead className="bg-dark text-white">
                        <div className="divbtn">
                        <Link to="employee/create" className="btn-primary">Add New (+)</Link>
                        </div>
                            <tr>
                                <td className="text">ID</td>
                                <td className="text">Name</td>
                                <td className="text">Email</td>
                                <td className="text">Phone</td>
                                <td className="text">Action</td>
                            </tr>
                        </thead>
                        <tbody>

                            {empdata &&
                                empdata.map(item => (
                                    <tr key={item.id}>
                                        <td >{item.id}</td>
                                        <td >{item.name}</td>
                                        <td >{item.email}</td>
                                        <td >{item.phone}</td>
                                        <td><button onClick={() => { LoadEdit(item.id) }} className="btn-success">Edit</button>
                                            <button onClick={() => { Removefunction(item.id) }} className="btn-delete">Remove</button>
                                            <button onClick={() => { LoadDetail(item.id) }} className="btn-view">Details</button>
                                        </td>
                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    );
}

export default Listing;