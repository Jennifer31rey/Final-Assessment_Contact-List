import React from 'react';
import "./styles/css/PageNotFound.css";
import { Link } from 'react-router-dom';
  
function PageNotFound() {
    return (
        <div>
          <h1> Oops! </h1>
           <p className='bold'> 404- PAGE NOT FOUND</p>
           <p> The page you are looking for might have been removed</p>
           <p> had its name changed or is temporarily unavailable.</p>

           <Link className="btn-error" to="/">GO TO HOMEPAGE</Link>
        </div>

    )

}
  
export default PageNotFound;